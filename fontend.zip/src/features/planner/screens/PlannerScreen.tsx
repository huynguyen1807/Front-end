import React from "react";
import { StyleSheet, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import TopNavbar from "../../../components/layout/TopNavbar";
import BottomNavbar from "../../../components/layout/BottomNavbar";
import ScreenContainer from "../../../components/layout/ScreenContainer";
import DailyGoalCard from "../components/DailyGoalCard";
import SuggestionSection from "../components/SuggestionSection";
import MealSchedule from "../components/MealSchedule";

export default function PlannerScreen() {
  const insets = useSafeAreaInsets();

  return (
    <ScreenContainer>
      <TopNavbar />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingBottom: 100, // Make room for bottom nav
          paddingHorizontal: 16,
          paddingTop: 16,
        }}
      >
        <DailyGoalCard />
        <SuggestionSection />
        <MealSchedule />
      </ScrollView>
      <BottomNavbar />
    </ScreenContainer>
  );
}
