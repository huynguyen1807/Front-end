import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Svg, { Circle } from "react-native-svg";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { COLORS } from "../../../constants/colors";

export default function DailyGoalCard() {
  const currentKcal = 1200;
  const totalKcal = 2000;
  const remainingKcal = totalKcal - currentKcal;
  const percentage = currentKcal / totalKcal;

  const radius = 50;
  const strokeWidth = 10;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - percentage * circumference;

  return (
    <View style={styles.card}>
      <Text style={styles.title}>MỤC TIÊU HÀNG NGÀY</Text>
      
      <View style={styles.calorieRow}>
        <Text style={styles.currentKcal}>1,200</Text>
        <Text style={styles.totalKcal}> / 2,000 kcal</Text>
      </View>
      
      <Text style={styles.subtitle}>
        Bạn còn {remainingKcal} kcal cho bữa tối!
      </Text>

      <View style={styles.chartContainer}>
        <Svg height="130" width="130" viewBox="0 0 130 130">
          <Circle
            cx="65"
            cy="65"
            r={radius}
            stroke="#e0e0e0"
            strokeWidth={strokeWidth}
            fill="none"
          />
          <Circle
            cx="65"
            cy="65"
            r={radius}
            stroke={COLORS.primary}
            strokeWidth={strokeWidth}
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            rotation="-90"
            origin="65, 65"
          />
        </Svg>
        <View style={styles.iconContainer}>
          <MaterialCommunityIcons name="silverware-fork-knife" size={32} color={COLORS.primary} />
        </View>
      </View>

      <View style={styles.macrosContainer}>
        <MacroBar label="Carbs" percent="45%" color="#916a00" />
        <MacroBar label="Protein" percent="30%" color={COLORS.primary} />
        <MacroBar label="Fat" percent="25%" color="#ba1a1a" />
      </View>
    </View>
  );
}

function MacroBar({ label, percent, color }: { label: string; percent: string; color: string }) {
  return (
    <View style={styles.macroCol}>
      <View style={styles.macroHeader}>
        <Text style={styles.macroLabel}>{label}</Text>
        <Text style={styles.macroPercent}>{percent}</Text>
      </View>
      <View style={styles.progressBarBg}>
        <View style={[styles.progressBarFill, { width: percent, backgroundColor: color }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surfaceContainer,
    borderRadius: 16,
    padding: 20,
    alignItems: "center",
    marginBottom: 20,
  },
  title: {
    fontSize: 12,
    fontWeight: "700",
    color: COLORS.onSurfaceVariant,
    marginBottom: 8,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  calorieRow: {
    flexDirection: "row",
    alignItems: "baseline",
    marginBottom: 4,
  },
  currentKcal: {
    fontSize: 36,
    fontWeight: "800",
    color: COLORS.primary,
  },
  totalKcal: {
    fontSize: 16,
    color: COLORS.onSurfaceVariant,
    fontWeight: "500",
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.onSurfaceVariant,
    marginBottom: 24,
  },
  chartContainer: {
    position: "relative",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 30,
  },
  iconContainer: {
    position: "absolute",
    justifyContent: "center",
    alignItems: "center",
  },
  macrosContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    paddingHorizontal: 10,
  },
  macroCol: {
    width: "30%",
  },
  macroHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  macroLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: COLORS.onSurfaceVariant,
  },
  macroPercent: {
    fontSize: 12,
    fontWeight: "600",
    color: COLORS.onSurfaceVariant,
  },
  progressBarBg: {
    height: 4,
    backgroundColor: "#e0e0e0",
    borderRadius: 2,
    overflow: "hidden",
  },
  progressBarFill: {
    height: "100%",
    borderRadius: 2,
  },
});
