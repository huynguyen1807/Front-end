import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../../../constants/colors";

interface TimelineItemProps {
  time: string;
  title: string;
  statusText: string;
  kcal: number;
  status: "completed" | "current" | "upcoming";
}

export default function TimelineItem({ time, title, statusText, kcal, status }: TimelineItemProps) {
  const isCompleted = status === "completed";
  const isCurrent = status === "current";
  const isUpcoming = status === "upcoming";

  const borderColor = isCompleted ? COLORS.primary : isCurrent ? COLORS.primary : "#e0e0e0";
  const containerStyle = [styles.card, { borderLeftColor: borderColor }];

  return (
    <View style={styles.container}>
      <Text style={styles.time}>{time}</Text>
      
      <View style={containerStyle}>
        <View style={styles.content}>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.subtitle}>
            {statusText} • {kcal} kcal
          </Text>
        </View>

        <TouchableOpacity style={styles.iconButton}>
          {isCompleted && (
            <Ionicons name="checkmark-circle-outline" size={24} color={COLORS.primary} />
          )}
          {isCurrent && (
            <Ionicons name="play-circle-outline" size={24} color={COLORS.onSurfaceVariant} />
          )}
          {isUpcoming && (
            <View style={styles.plusIcon}>
              <Ionicons name="add" size={20} color={COLORS.onSurfaceVariant} />
            </View>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  time: {
    width: 50,
    fontSize: 14,
    fontWeight: "700",
    color: COLORS.onSurface,
  },
  card: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: COLORS.surfaceContainerLowest,
    borderWidth: 1,
    borderColor: "#e0e0e0",
    borderLeftWidth: 4,
    borderRadius: 12,
    padding: 16,
    marginLeft: 8,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: "700",
    color: COLORS.onSurface,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 13,
    color: COLORS.onSurfaceVariant,
  },
  iconButton: {
    marginLeft: 12,
  },
  plusIcon: {
    backgroundColor: COLORS.surfaceContainer,
    borderRadius: 12,
    padding: 2,
  },
});
