import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity } from "react-native";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { COLORS } from "../../../constants/colors";

interface RecipeCardProps {
  title: string;
  time: string;
  kcal: number;
  tags: string[];
  imageUrl: string;
}

export default function RecipeCard({ title, time, kcal, tags, imageUrl }: RecipeCardProps) {
  return (
    <View style={styles.card}>
      <Image source={{ uri: imageUrl }} style={styles.image} />
      
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title} numberOfLines={2}>{title}</Text>
          <TouchableOpacity>
            <Ionicons name="heart-outline" size={20} color={COLORS.onSurfaceVariant} />
          </TouchableOpacity>
        </View>

        <View style={styles.meta}>
          <View style={styles.metaItem}>
            <Ionicons name="time-outline" size={14} color={COLORS.onSurfaceVariant} />
            <Text style={styles.metaText}>{time}</Text>
          </View>
          <View style={styles.metaItem}>
            <MaterialCommunityIcons name="fire" size={14} color={COLORS.primary} />
            <Text style={[styles.metaText, { color: COLORS.primary, fontWeight: "600" }]}>
              {kcal} kcal
            </Text>
          </View>
        </View>

        <View style={styles.tagsRow}>
          {tags.map((tag, index) => (
            <View key={index} style={styles.tag}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: COLORS.surfaceContainerLowest,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#e0e0e0",
    flexDirection: "row",
    overflow: "hidden",
    marginBottom: 16,
  },
  image: {
    width: 120,
    height: 120,
    backgroundColor: "#e0e0e0",
  },
  content: {
    flex: 1,
    padding: 12,
    justifyContent: "space-between",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  title: {
    flex: 1,
    fontSize: 16,
    fontWeight: "700",
    color: COLORS.onSurface,
    marginRight: 8,
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 6,
    marginBottom: 8,
  },
  metaItem: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 12,
  },
  metaText: {
    fontSize: 13,
    color: COLORS.onSurfaceVariant,
    marginLeft: 4,
  },
  tagsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 6,
  },
  tag: {
    backgroundColor: "#e0e0e0",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  tagText: {
    fontSize: 10,
    fontWeight: "700",
    color: COLORS.onSurfaceVariant,
  },
});
