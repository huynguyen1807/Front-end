import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { COLORS } from "../../../constants/colors";
import TimelineItem from "./TimelineItem";

const dates = [
  { id: "mon", label: "Thứ Hai (Nay)", active: true },
  { id: "tue", label: "Thứ Ba", active: false },
  { id: "wed", label: "Thứ Tư", active: false },
  { id: "thu", label: "Thứ Năm", active: false },
];

export default function MealSchedule() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Lịch trình bữa ăn</Text>

      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.tabsScroll}
        contentContainerStyle={styles.tabsContainer}
      >
        {dates.map((date) => (
          <TouchableOpacity
            key={date.id}
            style={[styles.tab, date.active && styles.activeTab]}
          >
            <Text style={[styles.tabText, date.active && styles.activeTabText]}>
              {date.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.timeline}>
        <TimelineItem
          time="08:00"
          title="Sữa chua Hy Lạp & Trái cây"
          statusText="Đã hoàn thành"
          kcal={280}
          status="completed"
        />
        <TimelineItem
          time="12:30"
          title="Salad Ức Gà Bơ"
          statusText="Đang chuẩn bị"
          kcal={350}
          status="current"
        />
        <TimelineItem
          time="19:00"
          title="Cá hồi nướng măng tây"
          statusText="Chưa thực hiện"
          kcal={570}
          status="upcoming"
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: "800",
    color: COLORS.onSurface,
    marginBottom: 16,
  },
  tabsScroll: {
    marginBottom: 24,
  },
  tabsContainer: {
    gap: 12,
  },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: COLORS.surfaceContainer,
  },
  activeTab: {
    backgroundColor: COLORS.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: "600",
    color: COLORS.onSurfaceVariant,
  },
  activeTabText: {
    color: COLORS.onPrimary,
  },
  timeline: {
    paddingRight: 8,
  },
});
