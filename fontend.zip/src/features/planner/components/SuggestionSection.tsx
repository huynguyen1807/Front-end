import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { COLORS } from "../../../constants/colors";
import RecipeCard from "./RecipeCard";

export default function SuggestionSection() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.titleContainer}>
          <MaterialCommunityIcons name="star-four-points-outline" size={24} color={COLORS.primary} />
          <Text style={styles.title}>Gợi ý hôm nay</Text>
        </View>
        <TouchableOpacity>
          <Text style={styles.seeAll}>Xem tất cả</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.banner}>
        <Text style={styles.bannerText}>
          Dựa trên <Text style={{ fontWeight: "700" }}>Bơ</Text> và <Text style={{ fontWeight: "700" }}>Ức gà</Text> sắp hết hạn trong 2 ngày tới.
        </Text>
      </View>

      <RecipeCard
        title="Salad Ức Gà Bơ"
        time="15 phút"
        kcal={350}
        tags={["GIÀU PROTEIN", "LOW CARB"]}
        imageUrl="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80"
      />
      <RecipeCard
        title="Buddha Bowl Thuần Chay"
        time="25 phút"
        kcal={420}
        tags={["THUẦN CHAY", "NHIỀU XƠ"]}
        imageUrl="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&q=80"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 24,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  title: {
    fontSize: 20,
    fontWeight: "800",
    color: COLORS.onSurface,
    marginLeft: 8,
  },
  seeAll: {
    fontSize: 14,
    fontWeight: "600",
    color: COLORS.primary,
  },
  banner: {
    backgroundColor: COLORS.secondaryContainer,
    padding: 16,
    borderRadius: 8,
    marginBottom: 16,
  },
  bannerText: {
    color: COLORS.onSecondaryContainer,
    fontSize: 14,
    lineHeight: 20,
  },
});
